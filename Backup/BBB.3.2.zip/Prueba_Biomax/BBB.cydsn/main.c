/*
*********************************************************************************************************
*                                           GRP550M CODE2
*
*                             (c) Copyright 2013; Sistemas Insepet LTDA
*
*               All rights reserved.  Protected by international copyright laws.
*               Knowledge of the source code may NOT be used to develop a similar product.
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                               GRP550M CODE
*
*                                             CYPRESS PSoC5LP
*                                                with the
*                                            CY8C5969AXI-LP035
*
* Filename      : main.c
* Version       : V2.00
* Programmer(s) : 
                  
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                             INCLUDE FILES
*********************************************************************************************************
*/

#include <device.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Protocolo.h"
#include "VariablesG.h"
#include "Print.h"
#include "LCD.h"
#include "ibutton.h"
#include "i2c.h"

/*
*********************************************************************************************************
*                                             DECLARACION DE FUNCIONES
*********************************************************************************************************
*/
uint8 letras[26]={0x25,0x42,0x31,0x27,0x1D,0x28,0x29,0x2A,0x22,0x2B,0x2C,0x2D,0x35,0x34,0x23,0x24,0x1B,0x1E,0x26,0x1F,0x21,0x32,0x1C,0x30,0x20,0x2F};
uint8 clave_config[5]="02412";
uint8 test[18]="Test de Impresora";
CY_ISR(animacion);
CY_ISR(animacion2);
CY_ISR(modo_mux);
uint8 idaux[8];
uint8 state_rf;
/*
*********************************************************************************************************
*                                         init( void )
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
void init(void){
	uint8 x,y,i;
    CyGlobalIntEnable;
    Surtidor_EnableRxInt();
	PC_Start();
    PC_EnableRxInt();
    I2C_1_Start();
    Surtidor_Start();
    Impresora_Start();
    LCD_1_Start();
    LCD_2_Start();
    LCD_1_EnableRxInt();
	LCD_2_EnableRxInt();
	Timer_Modo_Start();
	isr_5_StartEx(modo_mux);
	/***********Iniciacionde variables***************/
	lado1.grado[0][0]=0;
	lado1.grado[1][0]=0;
	lado1.grado[2][0]=0;
	lado2.grado[0][0]=0;
	lado2.grado[1][0]=0;
	lado2.grado[2][0]=0;
	for(y=0;y<=2;y++){
		for(x=0;x<=23;x++){
			lado1.totales[y][x]=0;
		}
	}
	for(y=0;y<=2;y++){
		for(x=0;x<=23;x++){
			lado2.totales[y][x]=0;
		}
	}	
    CyDelay(5);
	/******************Lectura de EEPROM*************/
	leer_eeprom(0,32);									//Nombre Estacion
    if((buffer_i2c[0]>0)&&(buffer_i2c[0]<=32)){
    	for(x=0;x<=buffer_i2c[0];x++){
    		nombre[x]=buffer_i2c[x];
    	}
    }
	leer_eeprom(32,15);									//Nit
    if((buffer_i2c[0]>0)&&(buffer_i2c[0]<=15)){
    	for(x=0;x<=buffer_i2c[0];x++){
    		nit[x]=buffer_i2c[x];		
    	}
    }
	leer_eeprom(64,32);									//Direccion
    if((buffer_i2c[0]>0)&&(buffer_i2c[0]<=32)){
    	for(x=0;x<=buffer_i2c[0];x++){
    		direccion[x]=buffer_i2c[x];		
    	}
    }
	leer_eeprom(47,12);									//Telefono
    if((buffer_i2c[0]>0)&&(buffer_i2c[0]<=12)){
    	for(x=0;x<=buffer_i2c[0];x++){
    		telefono[x]=buffer_i2c[x];		
    	}
    }
	leer_eeprom(128,32);								//Lema 1
    if((buffer_i2c[0]>0)&&(buffer_i2c[0]<=32)){
    	for(x=0;x<=buffer_i2c[0];x++){
    		lema1[x]=buffer_i2c[x];	
    	}
    }
	leer_eeprom(160,32);								//Lema 2
    if((buffer_i2c[0]>0)&&(buffer_i2c[0]<=32)){
    	for(x=0;x<=buffer_i2c[0];x++){
    		lema2[x]=buffer_i2c[x];
    	}
    }
	leer_eeprom(455,2);									//logo
	if(buffer_i2c[0]==1){
		 id_logo[0]=buffer_i2c[0]; 
		 id_logo[1]=buffer_i2c[1];
	}
	leer_eeprom(756,2);									//km
	if(buffer_i2c[0]==1){
		 km[0]=buffer_i2c[0]; 
		 km[1]=buffer_i2c[1];
	}		
	leer_eeprom(96,9);									//Pasword
	if((buffer_i2c[0]<=0x09)&&(buffer_i2c[0]>=0x01)){
		for(x=0;x<=7;x++){
			password_lcd[x+1]=buffer_i2c[x+1];
		}
		password_lcd[0]=buffer_i2c[0];
	}
	else{
		for(x=1;x<=8;x++){
			password_lcd[x]=x;
		}	
	}
	leer_eeprom(678,4);										//Numero de grados y codigo de cada uno 1
    if((buffer_i2c[0]<=4)&&(buffer_i2c[0]>0)){
    	lado1.mangueras=buffer_i2c[0];
    	for(x=0;x<buffer_i2c[0];x++){
    		lado1.grado[x][0]=buffer_i2c[x+1];	
    	}
    	i=0;
    	if((lado1.grado[0][0]==1)||(lado1.grado[1][0]==1)||(lado1.grado[2][0]==1)){
    		i=1;
    	}
    	if((lado1.grado[0][0]==2)||(lado1.grado[1][0]==2)||(lado1.grado[2][0]==2)){
    		i|=2;
    	}
    	if((lado1.grado[0][0]==3)||(lado1.grado[1][0]==3)||(lado1.grado[2][0]==3)){
    		i|=4;
    	}
    	switch(i){
			case 1:
				imagen_grado=1;	
			break;
			
			case 2:
				imagen_grado=1;	
			break;
			
			case 4:
				imagen_grado=1;	
			break;	
			
    		case 5:
    			imagen_grado=124;			
    		break;		
    		
    		case 3:
    			imagen_grado=125;	
    		break;
    		
    		case 6:
    			imagen_grado=127;	
    		break;	
    		
    		case 7:
    			imagen_grado=126;	
    		break;		
    	}
    }
	leer_eeprom(682,4);										//Numero de grado y codigo de cada uno 2
    if((buffer_i2c[0]<=4)&&(buffer_i2c[0]>0)){
    	lado2.mangueras=buffer_i2c[0];
    	for(x=0;x<buffer_i2c[0];x++){
    		lado2.grado[x][0]=buffer_i2c[x+1];
    	}
    }
	leer_eeprom(444,2);										//PPU X10
	if(buffer_i2c[0]==1){
		 ppux10=(buffer_i2c[1]&0x0f);
	}
	leer_eeprom(686,17);									//Nombre Codigo de Producto 1
    if((buffer_i2c[0]<=17)&&(buffer_i2c[0]>0)){
    	for(x=0;x<=buffer_i2c[0];x++){
    		nombre_pro1[x]=buffer_i2c[x];
    	}
    }
	leer_eeprom(704,17);									//Nombre Codigo de Producto 2
    if((buffer_i2c[0]<=17)&&(buffer_i2c[0]>0)){
    	for(x=0;x<=buffer_i2c[0];x++){
    		nombre_pro2[x]=buffer_i2c[x];
    	}
    }
	leer_eeprom(721,17);									//Nombre Codigo de Producto 3
    if((buffer_i2c[0]<=17)&&(buffer_i2c[0]>0)){    
    	for(x=0;x<=buffer_i2c[0];x++){
    		nombre_pro3[x]=buffer_i2c[x];
    	}
    }
	leer_eeprom(602,6);										//Version decimales dinero y decimales volumen
	if((buffer_i2c[0]==3)||(buffer_i2c[0]==1)||(buffer_i2c[0]==5)){
		 version[1]=(buffer_i2c[1]&0x0f);
		 version[2]=(buffer_i2c[2]&0x0f);
		 version[3]=(buffer_i2c[3]&0x0f);
	}
	leer_eeprom(608,2);										//Lado A
	if(buffer_i2c[0]==1){									
		lado1.dir=buffer_i2c[1];	
	}
	else{
		lado1.dir=0xFF;
	}
	leer_eeprom(610,2);										//Lado B
	if(buffer_i2c[0]==1){									
		lado2.dir=buffer_i2c[1];	
	}
	else{
		lado2.dir=0xFF;
	}
	leer_eeprom(666,2);										//Impresoras
	if(buffer_i2c[0]==1){
		 print1[1]=(buffer_i2c[1]&0x0f);
	}
	leer_eeprom(613,2);
	if(buffer_i2c[0]==1){
		 print2[1]=(buffer_i2c[1]&0x0f);
	}
    CyDelay(5);
}


/*
*********************************************************************************************************
*                             uint8 verificar_check(uint8 *datos, uint16 size)
*
* Description : calcula el checksum
*               

*********************************************************************************************************
*/
uint8 verificar_check(uint8 *datos, uint16 size){
	uint8 checksum,index;
	uint16 i;
    uint8 table[256] = { 
    0, 94,188,226, 97, 63,221,131,194,156,126, 32,163,253, 31, 65,
    157,195, 33,127,252,162, 64, 30, 95,  1,227,189, 62, 96,130,220,
    35,125,159,193, 66, 28,254,160,225,191, 93,  3,128,222, 60, 98,
    190,224,  2, 92,223,129, 99, 61,124, 34,192,158, 29, 67,161,255,
    70, 24,250,164, 39,121,155,197,132,218, 56,102,229,187, 89,  7,
    219,133,103, 57,186,228,  6, 88, 25, 71,165,251,120, 38,196,154,
    101, 59,217,135,  4, 90,184,230,167,249, 27, 69,198,152,122, 36,
    248,166, 68, 26,153,199, 37,123, 58,100,134,216, 91,  5,231,185,
    140,210, 48,110,237,179, 81, 15, 78, 16,242,172, 47,113,147,205,
    17, 79,173,243,112, 46,204,146,211,141,111, 49,178,236, 14, 80,
    175,241, 19, 77,206,144,114, 44,109, 51,209,143, 12, 82,176,238,
    50,108,142,208, 83, 13,239,177,240,174, 76, 18,145,207, 45,115,
    202,148,118, 40,171,245, 23, 73,  8, 86,180,234,105, 55,213,139,
    87,  9,235,181, 54,104,138,212,149,203, 41,119,244,170, 72, 22,
    233,183, 85, 11,136,214, 52,106, 43,117,151,201, 74, 20,246,168,
    116, 42,200,150, 21, 75,169,247,182,232, 10, 84,215,137,107, 53};	
	checksum=0;
	for(i=0;i<(size-1);i++){
		index = (uint8)(checksum ^ datos[i]);
		checksum = table[index];				
	}
	return checksum;
}

/*
************************************************************************************************************
*                                         void error_op()
*
* Description : Muestra en la pantalla el mensaje de operación incorrecta y regresa al inicio del Flujo LCD
*               
*
* Argument(s) : uint8 lcd, para elegir cual pantalla entra en esta función
*
* Return(s)   : none
*
* Caller(s)   : Desde cualquier momento de la operacion donde ocurra un error por parte del usuario
*
* Note(s)     : none.
************************************************************************************************************
*/
void error_op(uint8 lcd, uint16 imagen){
	if(lcd==1){
	    set_imagen(1,imagen);
	    flujo_LCD1=100;
		count_protector=1;
	    isr_3_StartEx(animacion);  
	    Timer_Animacion_Start();
	}
	else{
	    set_imagen(2,imagen);
	    flujo_LCD2=100;
		count_protector2=1;
	    isr_4_StartEx(animacion2);  
	    Timer_Animacion2_Start();	
	}
}

/*
*********************************************************************************************************
*                                         init_surt( void )
*
* Description : Busca las posiciones del surtidor y las graba en lado.a.dir y lado.b.dir
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : main()
*
* Note(s)     : Falta generar codigo para los casos 1 y 2
*********************************************************************************************************
*/
void init_surt(void){
	uint8 estado, ok=0, aux[15];
    /*lado1.dir=1;
    lado2.dir=2;*/
	while(ok!=2){
		ok=0;
		if((lado1.dir==0xFF)||(lado2.dir==0xFF)){
			while(ver_pos()==0);
			CyDelay(50);
			totales(lado1.dir, lado1.mangueras);
			CyDelay(50);	
			totales(lado2.dir, lado2.mangueras);
			CyDelay(50);	
			aux[0]=1;
			aux[1]=lado1.dir;
			if(write_eeprom(608,aux)){
				set_imagen(1,60);								
			}
			else{
				set_imagen(1,85);
			}
			aux[0]=1;
			aux[1]=lado2.dir;
			if(write_eeprom(610,aux)){
				set_imagen(2,60);								
			}
			else{
				set_imagen(2,85);
			}
			flujo_LCD2=0;
			flujo_LCD1=0;			
			ok=2;			
		}
		else{
			estado=get_estado(lado1.dir);										
			switch(estado){
		         case 0:                     
					lado1.dir=0xFF;
				 break;	
			
				case 0x06:
					venta(lado1.dir);
					CyDelay(50);	
					totales(lado1.dir, lado1.mangueras);
					CyDelay(50);	
					flujo_LCD1=0;					
					ok++;
				break;
					
				case 0x07:	
					totales(lado1.dir, lado1.mangueras);
					CyDelay(50);	
					flujo_LCD1=0;					
					ok++;
				break;
				
				case 0x08:
			     	flujo_LCD1=11;
					ok++;
				break;
					
				case 0x09:
			     	flujo_LCD1=11;
					ok++;
				break;
				
		         case 0x0B:                     //Termino venta
					flujo_LCD1=12;
					ok++;
				 break;	
					
		         case 0x0A:						//Termino venta
					flujo_LCD1=12;
					ok++;
				 break;
					
		         case 0x0C:						//Bloqueado por surtiendo al iniciar
			     	flujo_LCD1=11;
				 	set_imagen(1,8);
					ok++;
				 break;					
					
			}
			estado=get_estado(lado2.dir);										
			switch(estado){
		         case 0:                     
					lado2.dir=0xFF;
				 break;	
			
				case 0x06:
					venta(lado2.dir);
					CyDelay(50);		
					totales(lado2.dir, lado2.mangueras);
					CyDelay(50);	
					flujo_LCD2=0;				
					ok++;
				break;
					
				case 0x07:	
					totales(lado2.dir, lado2.mangueras);
					CyDelay(50);	
					flujo_LCD2=0;					
					ok++;
				break;
				
				case 0x08:
			     	flujo_LCD2=11;
				 	set_imagen(2,8);
					ok++;
				break;
					
				case 0x09:
			     	flujo_LCD2=11;
				 	set_imagen(2,8);
					ok++;
				break;
				
		         case 0x0B:                     //Termino venta
					flujo_LCD2=12;
					ok++;
				 break;	
					
		         case 0x0A:						//Termino venta
					flujo_LCD2=12;
					ok++;
				 break;
					
		         case 0x0C:						//Bloqueado por surtiendo al iniciar
			     	flujo_LCD2=11;
				 	set_imagen(2,8);
					ok++;
				 break;										
			}			
		}
	}
}

/*
*********************************************************************************************************
*                                         uint8 polling_rf(void)
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/

void polling_rf(void){
	uint16 status1, status2,size,i,x,manguera,t_preset;
	uint8  buffer_rf[1500],precio[5],preset[7];
	if(PC_GetRxBufferSize()>=6){
		status1=PC_GetRxBufferSize();
		CyDelayUs(3000);
		status2=PC_GetRxBufferSize();
		if(status1==status2){
			size=PC_GetRxBufferSize();
			i=0;
		    while(PC_GetRxBufferSize()>0){
		       buffer_rf[i]=PC_ReadRxData(); 	
			   i++;	
		    }			
			if((buffer_rf[0]=='B')&&(buffer_rf[1]=='B')&&(buffer_rf[2]=='B')){
				ok_datosRF=0;
				if(buffer_rf[4]==lado1.dir){
					manguera=rventa1.manguera;
					t_preset=rventa1.preset[0];
				}else if(buffer_rf[4]==lado2.dir){
					manguera=rventa2.manguera;
					t_preset=rventa2.preset[0];
				}
				switch(buffer_rf[3]){
					case cautorizar:
						if(buffer_rf[5]=='N'){			//No autorizo el servidor		
							set_imagen(buffer_rf[4],55);
							i=6;
							while(i!='*'){
								write_psoc1(print1[(buffer_rf[4]-0x30)],buffer_rf[i]);
								i++;
							}	
							if(lado1.dir==buffer_rf[4]){
								lado1.estado=libre;
							}
							else if(lado2.dir==buffer_rf[4]){
								lado2.estado=libre;
							}
							error_op(buffer_rf[4],28);
							break;
						}
						if(rf_mod[11]!='F'){		//Cambia precio
							precio[0]=buffer_rf[11];	
							precio[1]=buffer_rf[10];
							precio[2]=buffer_rf[9];
							precio[3]=buffer_rf[8];
							precio[4]=buffer_rf[7];
							if(cambiar_precio(buffer_rf[4],precio,manguera)==0){
								rf_mod[0]='M';
								rf_mod[1]='U';
								rf_mod[2]='X';
								rf_mod[3]=cerror;
								rf_mod[4]=cautorizar;
								rf_mod[5]=buffer_rf[4];
								rf_mod[6]='1';
								rf_mod[7]='*';
								size=8;
								ok_datosRF=1;
								break;
							}
						}
						preset[0]=buffer_rf[17];
						preset[1]=buffer_rf[16];
						preset[2]=buffer_rf[15];
						preset[3]=buffer_rf[14];
						preset[4]=buffer_rf[13];
						preset[5]=buffer_rf[12];
						preset[6]=buffer_rf[11];
						if(programar(buffer_rf[4],manguera,preset,t_preset)==1){
							CyDelay(10);
							Surtidor_PutChar(0x10|buffer_rf[4]);							
							if(buffer_rf[4]==lado1.dir){
								lado1.estado=tanqueo;
								flujo_LCD1=11;
								set_imagen(1,8);
							}
							else{
								lado2.estado=tanqueo;
								flujo_LCD2=11;
								set_imagen(2,8);
							}
						}
						else{
							rf_mod[0]='M';
							rf_mod[1]='U';
							rf_mod[2]='X';
							rf_mod[3]=cerror;
							rf_mod[4]=cautorizar;
							rf_mod[5]=buffer_rf[4];
							rf_mod[6]='2';
							rf_mod[7]='*';
							size=8;
							ok_datosRF=1;							
						}
					break;
					
					case cimprimir:
						i=5;
						set_imagen(buffer_rf[4],55);
						while(i!='*'){
							write_psoc1(print1[(buffer_rf[4]-0x30)],buffer_rf[i]);
							i++;
						}
						lado1.estado=libre;
						flujo_LCD1=0;						
					break;
					
					case cerror:
						switch(buffer_rf[5]){
							case '1':
								i=6;
								set_imagen(buffer_rf[4],55);
								while(i!='*'){
									write_psoc1(print1[(buffer_rf[4]-0x30)],buffer_rf[i]);
									i++;
								}
								lado1.estado=libre;
								error_op(buffer_rf[4],28);
							break;
						}
					break;		
				}
				if(ok_datosRF==1){
				    for(x=0;x<size;x++){
					   PC_PutChar(rf_mod[x]);
				    }							
				}
			}
			PC_ClearRxBuffer();
			status1=0;
			status2=0;			
		}		
	}	
}

/*
*********************************************************************************************************
*                                         uint8 polling_mod(void)
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/

void polling_sof(void){
	if(PC_GetRxBufferSize()>=6){
		
	}		
}



/*
*********************************************************************************************************
*                                         void polling_LCD1(void)
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/

void polling_LCD1(void){
	uint8 x,y,aux[10];
	char numero[8];
	double num_decimal;
	
	switch(flujo_LCD1){
        case 0:
         isr_3_StartEx(animacion); 
         Timer_Animacion_Start();
         count_protector=0;
         flujo_LCD1=1;	       
        break;
		
        case 1:
         if(LCD_1_GetRxBufferSize()==8){ 
             isr_3_Stop(); 
             Timer_Animacion_Stop(); 
	         flujo_LCD1=2;
	         set_imagen(1,18);				
             LCD_1_ClearRxBuffer();				
         }
        break;
		
        case 2: 
         if(LCD_1_GetRxBufferSize()==8){
            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
				count_protector=0;
                if(count_teclas1<teclas1){									
                    if(LCD_1_rxBuffer[3]<=9){								//Numero de 1-9
                        count_teclas1++;
                        Buffer_LCD1[count_teclas1]=LCD_1_rxBuffer[3];
                        write_LCD(1,(LCD_1_rxBuffer[3]+0x30), posy1, ((count_teclas1*(sizeletra1+1))+posx1), sizeletra1);
                    }
                    if(LCD_1_rxBuffer[3]==0x0A){            				//Comando de 0
						if((id_teclado1==1)&&(count_teclas1==1)&&(Buffer_LCD1[1]==0)){
						}
						else{
	                        count_teclas1++;
	                        Buffer_LCD1[count_teclas1]=0;
							write_LCD(1,0x30, posy1, ((count_teclas1*(sizeletra1+1))+posx1), sizeletra1);
						}
                    }  
                    if(LCD_1_rxBuffer[3]==0x51){            	 			//Comando de Coma
                        if(count_teclas1>=1 && comas1==0){
                            count_teclas1++;
                            Buffer_LCD1[count_teclas1]=id_coma1;
							write_LCD(1,id_coma1, posy1, ((count_teclas1*(sizeletra1+1))+posx1), sizeletra1);
                            comas1=1;
                        }
                    }                    
                }
                if(LCD_1_rxBuffer[3]==0x0B){								//Cancel
                    if(count_teclas1==0){
						switch(id_teclado1){
							case 1:
							set_imagen(1,5);
							flujo_LCD1=4;
							break;
							
							case 2:
	                        flujo_LCD1=0;	
							break;
							
							case 3:
							set_imagen(1,0);
							flujo_LCD1=0;
							lado1.estado=1;
							break;
							
							case 4:
							set_imagen(1,0);
							flujo_LCD1=0;
							lado1.estado=1;
							break;							
						}
                    }
                    else{
						write_LCD(1,0x20, posy1, ((count_teclas1*(sizeletra1+1))+posx1), sizeletra1);
                        if(Buffer_LCD1[count_teclas1]==id_coma1){
                            comas1=0;
                        }
						Buffer_LCD1[count_teclas1]=0;
                        count_teclas1--;
                    }
                }
                if(LCD_1_rxBuffer[3]==0x0C){								//Enter
					switch(id_teclado1){
						case 1:
							for(x=0;x<=7;x++){
								numero[x]=0;
							}						
							if((count_teclas1>=1)&&(Buffer_LCD1[count_teclas1]!='.')){
								for(x=1;x<=count_teclas1;x++){
									if(Buffer_LCD1[x]!='.'){
										numero[x-1]=Buffer_LCD1[x]+48;
									}
									else{
										numero[x-1]=Buffer_LCD1[x];
									}
								}
								num_decimal=atof(numero);
								if(((rventa1.preset[0]==2)&&(num_decimal>=800))||((rventa1.preset[0]==1)&&(num_decimal<=900)&&(num_decimal>0))){
									for(x=count_teclas1;x>=1;x--){
										rventa1.preset[x]=Buffer_LCD1[(count_teclas1-x)+1];
									}
									flujo_LCD1=5;								
						            flujo_LCD1=6;                         
						            set_imagen(1,7);
								}
							}
						break;
							
						case 2:							
							for(x=count_teclas1;x>=1;x--){
								rventa1.km[x]=Buffer_LCD1[(count_teclas1-x)+1];
							}
							if(rventa1.tipo_venta==1){
	                        	flujo_LCD1=4;	
	                        	set_imagen(1,5);
							}
							else{
								count_teclas1=0;
								teclas1=7;
								posx1=4;
								posy1=3;
								sizeletra1=1;				
								set_imagen(1,10);
								flujo_LCD1=13;
								count_protector=0;
							}
						break;
							
						case 3:
							for(x=count_teclas1;x>=1;x--){
								rventa1.cedula[x]=Buffer_LCD1[(count_teclas1-x)+1]+48;
							}
                        	flujo_LCD1=2;	
                        	set_imagen(1,37);
							count_teclas1=0;
							id_teclado1=4;
							teclas1=10;
							posx1=2;
							posy1=3;
							sizeletra1=1;								
						break;
							
						case 4:
							for(x=count_teclas1;x>=1;x--){
								rventa1.password[x]=Buffer_LCD1[(count_teclas1-x)+1]+48;
							}
                        	flujo_LCD1=102;	
                        	set_imagen(1,57);
							lado1.estado=16;
						break;							
							
					}					
                }
            }
            //CyDelay(100);            
            LCD_1_ClearRxBuffer();
         }
		 if((count_protector>=30)&&(rventa1.tipo_venta==0)&&(id_teclado1==2)){
			count_teclas1=0;
			teclas1=7;
			posx1=4;
			posy1=3;
			sizeletra1=1;				
			set_imagen(1,10);
			flujo_LCD1=13;
			count_protector=0;
		 }		
        break;		
		
		case 3:
         if(touch_present(1)==1){
             if(touch_write(1,0x33)){
	             for(x=0;x<=7;x++){
	                 rventa1.id[x]=touch_read_byte(1);
	             }
				 crc_total=0;
				 for(x=0;x<7;x++){
				 	crc_total=crc_check(crc_total,rventa1.id[x]);
				 }					
				 if(crc_total==rventa1.id[7]){
		             set_imagen(1,19);
		             count_protector=0;              
		             isr_3_StartEx(animacion); 
		             Timer_Animacion_Start(); 
					 flujo_LCD1=101;
					 prox_caso[0][0]=2;
					 prox_caso[0][1]=14;
					 count_teclas1=0;							//Inicia el contador de teclas	
					 id_teclado1=2;
					 teclas1=10;
					 posx1=2;
					 posy1=3;
					 sizeletra1=1;	
				 }
             }
         }
         if(LCD_1_GetRxBufferSize()==8){
            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
                switch(LCD_1_rxBuffer[3]){
                    case 0x3B:
                     flujo_LCD1=0; 
                    break; 
                }
            }
            //CyDelay(100);            
            LCD_1_ClearRxBuffer();
         }		
		break;		
		
        case 4:   
         if(LCD_1_GetRxBufferSize()==8){
            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
                switch(LCD_1_rxBuffer[3]){
                    case 0x0F:                               	//$
					  for(x=0;x<=7;x++){
					 	rventa1.preset[x]=0;
					  }					
                      flujo_LCD1=2; 
					  count_teclas1=0;							//Inicia el contador de teclas	
					  id_teclado1=1;
					  id_coma1='.';	
                      teclas1=version[1]; 						//cantidad de teclas q puede digitar
					  rventa1.preset[0]=2;
                      comas1=0;									
                      set_imagen(1,6); 
					  posx1=4;
					  posy1=3;
					  sizeletra1=1;	
					  write_LCD(1,'$', 3, 4, 1);
                    break;
                    
                    case 0x10: 									//G 
					  for(x=0;x<=7;x++){
					 	rventa1.preset[x]=0;
					  }						
                      flujo_LCD1=2; 
					  count_teclas1=0;							//Inicia el contador de teclas	
					  id_teclado1=1;
					  id_coma1='.';	
                      teclas1=version[1]; 
					  rventa1.preset[0]=1;
                      comas1=0;									
                      set_imagen(1,13); 
					  posx1=4;
					  posy1=3;
					  sizeletra1=1;					
					  write_LCD(1,'G', 3, 4, 1);
                    break;
                    
                    case 0x43:  								//Full 
					  for(x=0;x<=7;x++){
					 	rventa1.preset[x]=0;
					  }
                      rventa1.preset[0]=3;					
					  for(x=5;x<=7;x++){
						rventa1.preset[x]=9;		
					  }						
		              flujo_LCD1=6;                         
		              set_imagen(1,7);						
                    break;
                    
                    case 0x3B:                                //Cancel                     
                      flujo_LCD1=0;
                    break;                    
                }
            }
            //CyDelay(100);            
            LCD_1_ClearRxBuffer();
         } 
        break;
		
		case 5:
		 CyDelay(50);
         if(LCD_1_GetRxBufferSize()==8){
            if((LCD_1_rxBuffer[0]==0xAA) && (LCD_1_rxBuffer[6]==0xC3) && (LCD_1_rxBuffer[7]==0x3C)){
                if(LCD_1_rxBuffer[3]==0x7E){					//Cancel
					flujo_LCD1=0;
                }												
			}
            //CyDelay(100);            
            LCD_1_ClearRxBuffer();
			break;
		 }
         x=get_estado(lado1.dir);
         if(x==7){								//Espera a que este en listo el equipo	
			flujo_LCD1=7;
            CyDelay(50);
         }
         else if(x==0){
			CyDelay(50);
			programar(lado1.dir,1,aux,2);
         }
         else if(x==0x0C){
            error_op(1,85);
         }
		 else if(x==0x0B){                   //Termino venta
			flujo_LCD1=12;
         }						
		 else if(x==0x0A){					//Termino venta
			flujo_LCD1=12;
		 }        
        break;
		
		case 7:
		 CyDelay(10);
		 rventa1.manguera=estado_ex(lado1.dir);
		 if(rventa1.manguera!=0){
			flujo_LCD1=8; 
            CyDelay(10);		
		 }	
		break;
		
		case 8:
         CyDelay(10);
		 if(get_estado(lado1.dir)==7){
			flujo_LCD1=9;
			set_imagen(1,57);
			lado1.estado=listo;
		 }
		break;
		
		case 9:
			if(lado2.estado==libre){
				rf_mod[0]='M';
				rf_mod[1]='U';
				rf_mod[2]='X';
				rf_mod[3]='0';
				for(x=0;x<=15;x++){						//Serial				
					y=(rventa1.id[x/2]>>4)&0x0F;
					if((x%2)==0){
						y=rventa1.id[x/2]&0x0F;
					}
					rf_mod[x+4] = y+48;
					if(y>9){
						rf_mod[x+4] = y+55;
					}
				}
				rf_mod[20]=rventa1.preset[0];			//Tipo de Preset
				for(x=1;x<=7;x++){						//Preset
					rf_mod[21+x]=rventa1.preset[x];
				}
				for(x=0;x<=6;x++){						//Km
					rf_mod[28+x]=rventa1.km[x+1];
				}					
				for(x=0;x<=4;x++){						//PPU	
					rf_mod[35+x]=lado1.ppu[rventa1.manguera-1][x]&0x0F;
				}
				rf_mod[40]=lado1.grado[rventa1.manguera-1][0];
				rf_mod[41]=lado1.dir;
				rf_mod[42]='*';
				PC_ClearRxBuffer();
			    for(x=0;x<43;x++){
				   PC_PutChar(rf_mod[x]);
			    }
				CyDelay(100);
				if(PC_GetRxBufferSize()==2){
					if((PC_rxBuffer[0]=='O') && (PC_rxBuffer[6]=='K')){
						lado1.estado=espera;
						flujo_LCD1=10;
					}	
				}
			}
		break;
		
		case 10:
			
		break;	
		
		case 11:
		 CyDelay(50);
		 switch(get_estado(lado1.dir)){
	         case 0x0B:                     //Termino venta
				CyDelay(100);
				for(x=0;x<=8;x++){
					rventa1.dinero[x]=0;
					rventa1.volumen[x]=0;
				}					
				if(venta(lado1.dir)==1){
					flujo_LCD1=12;
				}	
			 break;	
				
	         case 0x0A:						//Termino venta
				for(x=0;x<=8;x++){
					rventa1.dinero[x]=0;
					rventa1.volumen[x]=0;
				}				
				if(venta(lado1.dir)==1){
					flujo_LCD1=12;
				}	
			 break;

	         case 0x06:                     //No hizo venta
				flujo_LCD1=100;
				leer_hora();
				leer_fecha();
				venta(lado1.dir);
				lado1.estado=12;
		        isr_3_StartEx(animacion); 
		        Timer_Animacion_Start();
		        count_protector=1;				
			 break;				 	
         }		 	
		break;
		
		case 12:
			if(lado2.estado==libre){
				rf_mod[0]='M';
				rf_mod[1]='U';
				rf_mod[2]='X';
				rf_mod[3]='1';
				if(version[1]==7){
					rf_mod[4]=rventa1.dinero[7] + 48;	//Dinero 7 digitos
					rf_mod[5]=rventa1.dinero[6] + 48;
					rf_mod[6]=rventa1.dinero[5] + 48;
					rf_mod[7]=rventa1.dinero[4] + 48;
					rf_mod[8]=rventa1.dinero[3] + 48;
					rf_mod[9]=rventa1.dinero[2] + 48;
					rf_mod[10]=rventa1.dinero[1] + 48;					
				}
				else{
					rf_mod[4]=rventa1.dinero[6] + 48;	//Dinero 6 digitos 
					rf_mod[5]=rventa1.dinero[5] + 48;
					rf_mod[6]=rventa1.dinero[4] + 48;
					rf_mod[7]=rventa1.dinero[3] + 48;
					rf_mod[8]=rventa1.dinero[2] + 48;
					rf_mod[9]=rventa1.dinero[1] + 48;					
					rf_mod[10]=rventa1.dinero[0] + 48;
				}
				rf_mod[11]=rventa1.volumen[5] + 48;				//Volumen
				rf_mod[12]=rventa1.volumen[4] + 48;
				rf_mod[13]=rventa1.volumen[3] + 48;
				rf_mod[14]='.';
				rf_mod[15]=rventa1.volumen[2] + 48;
				rf_mod[16]=rventa1.volumen[1] + 48;
				rf_mod[17]=rventa1.volumen[0] + 48;				
				rf_mod[18]=lado1.dir;							//Cara
				rf_mod[19]=rventa1.producto-1;					//Id Producto								
				rf_mod[20]='*';
				PC_ClearRxBuffer();
			    for(x=0;x<20;x++){
				   PC_PutChar(rf_mod[x]);
			    }
				CyDelay(100);
				if(PC_GetRxBufferSize()==2){
					if((PC_rxBuffer[0]=='O') && (PC_rxBuffer[6]=='K')){
						lado1.estado=espera;
						flujo_LCD1=0;
					}	
				}
			}
		break;
		
			
	}	
	
}


/*
*********************************************************************************************************
*                                         void polling_LCD2(void)
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/

void polling_LCD2(void){
		
}

/*
*********************************************************************************************************
*                                        void polling_wd(void)
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
void polling_wd(void){

}

/*
*********************************************************************************************************
*                                         CY_ISR(animacion)
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
CY_ISR(animacion){
    Timer_Animacion_ReadStatusRegister();
    if(flujo_LCD1==1){
        if(count_protector<=6){
            count_protector++;
            set_imagen(1,(iprotector5+count_protector));  
        }
        else{
           count_protector=0; 
           set_imagen(1,(iprotector5+count_protector));  
        }
    }
    else{
        count_protector++;
    }
}

/*
*********************************************************************************************************
*                                         CY_ISR(animacion)
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
CY_ISR(animacion2){
    Timer_Animacion2_ReadStatusRegister();
    if(flujo_LCD2==1){
        if(count_protector2<=6){
            count_protector2++;
            set_imagen(2,(iprotector5+count_protector2));  
        }
        else{
           count_protector2=0; 
           set_imagen(2,(iprotector5+count_protector2));  
        }
    }
    else{
        count_protector2++;
    }
}

/*
*********************************************************************************************************
*                                        CY_ISR(modo_mux)
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
CY_ISR(modo_mux){
	Timer_Modo_ReadStatusRegister();
	state_rf++;
	if(state_rf==15){
		if((rventa1.autorizado!=100)&&(rventa2.autorizado!=100)){
			rventa1.autorizado=0;
			rventa2.autorizado=0;
		}	
		state_rf=0;
	}
}

/*
*********************************************************************************************************
*                                         main( void )
*
* Description : 
*               
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : 
*
* Note(s)     : none.
*********************************************************************************************************
*/
int main()
{
    init();
	init_surt();
	CyWdtStart(CYWDT_1024_TICKS,CYWDT_LPMODE_NOCHANGE); 	
    for(;;)
    {		
       	polling_rf();
       	polling_LCD1();
		CyWdtClear();
	   	polling_rf();
		
		CyWdtClear();
    }
}

/* [] END OF FILE */
